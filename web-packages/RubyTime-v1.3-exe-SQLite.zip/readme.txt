 ____        _          _____ _                
|  _ \ _   _| |__  _   |_   _(_)_ __ ___   ___ 
| |_) | | | | '_ \| | | || | | | '_ ` _ \ / _ \
|  _ <| |_| | |_) | |_| || | | | | | | | |  __/
|_| \_\\__,_|_.__/ \__, ||_| |_|_| |_| |_|\___|
                   |___/                       

Welcome to RubyTime. Follow those steps to run the application:
  1) Unzip the archive with RubyTime distribution.
  2) Run rubytime.exe file. First run may take 10-15 seconds.
  3) Point your browser to http://localhost:3000
  4) Default admin account is:
       -> login:    admin
       -> password: admin 