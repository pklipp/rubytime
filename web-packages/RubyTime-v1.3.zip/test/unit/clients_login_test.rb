require File.dirname(__FILE__) + '/../test_helper'

class ClientsLoginTest < Test::Unit::TestCase
  fixtures :clients_logins

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
