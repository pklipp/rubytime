require File.dirname(__FILE__) + '/../test_helper'

class InvoiceTest < Test::Unit::TestCase
  fixtures :invoices

  # Replace this with your real tests.
  def test_truth
    assert true
  end
  
end
