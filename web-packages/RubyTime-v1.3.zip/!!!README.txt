Help and instalation guide is available at:
http://clients.llp.pl/doku.php?id=rubytimetracker:ruby_time_tracker_support