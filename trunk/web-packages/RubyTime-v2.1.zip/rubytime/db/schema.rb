# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of ActiveRecord to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 8) do

  create_table "activities", :force => true do |t|
    t.text     "comments"
    t.date     "date",                      :null => false
    t.integer  "minutes",    :default => 0, :null => false
    t.integer  "project_id",                :null => false
    t.integer  "user_id",                   :null => false
    t.integer  "invoice_id"
    t.datetime "created_at"
  end

  add_index "activities", ["user_id"], :name => "index_activities_on_user_id"
  add_index "activities", ["project_id"], :name => "index_activities_on_project_id"

  create_table "clients", :force => true do |t|
    t.string  "name",                           :null => false
    t.text    "description"
    t.boolean "is_inactive", :default => false, :null => false
  end

  add_index "clients", ["name"], :name => "index_clients_on_name", :unique => true

  create_table "clients_logins", :force => true do |t|
    t.string  "login",     :null => false
    t.string  "password",  :null => false
    t.integer "client_id", :null => false
  end

  add_index "clients_logins", ["login"], :name => "index_clients_logins_on_login", :unique => true
  add_index "clients_logins", ["client_id"], :name => "index_clients_logins_on_client_id"

  create_table "invoices", :force => true do |t|
    t.string   "name",                          :null => false
    t.text     "notes"
    t.integer  "client_id",                     :null => false
    t.integer  "user_id",                       :null => false
    t.datetime "created_at"
    t.boolean  "is_issued",  :default => false, :null => false
    t.datetime "issued_at"
  end

  add_index "invoices", ["name"], :name => "index_invoices_on_name", :unique => true
  add_index "invoices", ["user_id"], :name => "index_invoices_on_user_id"
  add_index "invoices", ["client_id"], :name => "index_invoices_on_client_id"

  create_table "projects", :force => true do |t|
    t.string   "name",                           :null => false
    t.text     "description"
    t.integer  "client_id",                      :null => false
    t.boolean  "is_inactive", :default => false, :null => false
    t.datetime "created_at"
  end

  add_index "projects", ["name"], :name => "index_projects_on_name", :unique => true
  add_index "projects", ["client_id"], :name => "index_projects_on_client_id"

  create_table "roles", :force => true do |t|
    t.string  "name",                                       :null => false
    t.string  "short_name", :limit => 5,                    :null => false
    t.boolean "is_admin",                :default => false, :null => false
  end

  add_index "roles", ["short_name"], :name => "index_roles_on_short_name", :unique => true
  add_index "roles", ["name"], :name => "index_roles_on_name", :unique => true

  create_table "users", :force => true do |t|
    t.string   "login",                            :null => false
    t.string   "password_hash",                    :null => false
    t.string   "name",                             :null => false
    t.string   "email",                            :null => false
    t.integer  "role_id",                          :null => false
    t.boolean  "is_inactive",   :default => false, :null => false
    t.string   "salt",                             :null => false
    t.datetime "created_at"
    t.string   "password_code"
  end

  add_index "users", ["login"], :name => "index_users_on_login", :unique => true
  add_index "users", ["role_id"], :name => "index_users_on_role_id"

end
