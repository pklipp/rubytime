at_exit do
  require "irb"
  require "drb/acl"
  require "sqlite3"
end

ENV['RAILS_ENV'] = 'production'
load "script/server"
